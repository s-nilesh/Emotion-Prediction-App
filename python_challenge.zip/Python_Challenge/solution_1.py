import argparse

def split_into_container(sentence, n):
    """
    Function to split a given sentence into word containers containing
    n or fewer charaters.
    
    Params-
    sentence:= given input sentence
    n:= given length(size) of container
    """
    output = []
    words = sentence.split(' ')  # list of all words present in sentence
    
    if n < len(words[0]):
        return output

    seq_len = len(words[0])   # initializing the character count
    seq_lengths = [seq_len]   # list of contiguous character count

    for word in words[1:]:    # building seq_lengths including one white-space between two consecutive words
        seq_len += (len(word)+1)
        seq_lengths.append(seq_len)

    while words:
        valid_words = [n-x for x in seq_lengths]    # finding words that will fit in given criteria
        # extract index of the valid words to make word container
        valid_indexes = [index for index,value in enumerate(valid_words) if value >= 0]   
        
        output.append(' '.join([words[x] for x in valid_indexes]))    # appending valid word container to output
        
        for x in valid_indexes:     # pop the, now redundant/ used words
            words.pop(0)
            seq_lengths.pop(0)
        
        # update seq_lengths for next iteration
        seq_lengths = [x-(seq_lengths[0]-len(words[0])) for x in seq_lengths]     

    return output


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--sentence", required=True, help='Enter the sentence to be divided into word containers')
    ap.add_argument("--container_size", required=True, help="Enter container size/length")
    ap = vars(ap.parse_args())
    sentence = ap['sentence']
    n = int(ap['container_size'])
    output_list = split_into_container(sentence, n)
    print(output_list)