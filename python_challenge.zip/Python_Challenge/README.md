# Problem Statement:
Write a function that divides a sentence into word container with each container containing "n" or fewer characters. Only include "full words" inside each container.

**Solutions** scripts are names as 'solution_1.py' and 'solution_2.py'<br>

To run these scripts, (sample command given below):
> `python solution_1.py --sentence "she sells sea shells by the sea" --container_size 10`