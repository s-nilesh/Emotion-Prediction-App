import argparse

def create_new_seq(pointer,sentence, n):
    """
    Function to create new sequence every time a new pointer is created.
    
    Params - 
    pointer:= index of the character which is being treated as the starting 
    charcter for the new sequence
    sentence: given input sentence
    n: given length(size) of container
    """
    if (len(sentence) - (n+pointer))>= 0:
        new_seq = sentence[pointer:pointer+n]
        break_flag = 0
    elif (len(sentence) - (pointer)) < 0:
        new_seq = None
        break_flag = 1
    else:
        new_seq = sentence[pointer:]
        break_flag = 1
    return new_seq, break_flag


def split_into_container(sentence, n):
    """
    Function to split a given sentence into word containers containing
    n or fewer charaters.
    
    Params-
    sentence: given input sentence
    n: given length of container
    """
    output = []
    pointer = 0
    words = sentence.split()     # list of all words present in sentence
    if n < len(words[0]):        # return empty list if n < first word length
        return output
    while True:
        # print(pointer)
        
        # create a new sequence
        new_seq, break_flag = create_new_seq(pointer, sentence, n)  
        if break_flag:
            break
        
        # eleminating leading white-space if present
        if new_seq[0] == ' ':
            pointer += 1
            new_seq, break_flag = create_new_seq(pointer, sentence, n)

        # striping ending white space, verifying valid word end for the sequence
        if new_seq.rstrip().split(' ')[-1] in words:
            output.append(new_seq.rstrip())
            pointer += n

        else:
            # in case of invalid last word, append a valid sequence by eleminating 
            # the last invalid word
            new_seq = ' '.join(new_seq.split(' ')[:-1])   
            output.append(new_seq)
            pointer += len(new_seq)
            
    return output



if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--sentence", required=True, help='Enter the sentence to be divided into word containers')
    ap.add_argument("--container_size", required=True, help="Enter container size/length")
    ap = vars(ap.parse_args())
    sentence = ap['sentence']
    n = int(ap['container_size'])
    output_list = split_into_container(sentence, n)
    print(output_list)